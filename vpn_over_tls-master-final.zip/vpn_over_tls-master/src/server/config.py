config = {
	"TUN_ADDRESS": "10.0.1.1",
	"TUN_NETMASK": "255.255.255.0",
	"LISTEN_ADDRESS": "192.168.234.7",
	"LISTEN_PORT": 443,
	"TUN_NAME": "tun0",
	"TUN_MTU": 1500, 
	"BUFFER_SIZE": 1500,
	"CERTIFICATE_CHAIN": "/home/mpaud002/5G_PQ/vpn_over_tls-master/src/newCerts/dilithium2/svrcert.pem",
	"PRIVATE_KEY": "/home/mpaud002/5G_PQ/vpn_over_tls-master/src/newCerts/dilithium2/svrkey.pem",
	"SALT": "WH!{*ewP]x}0RHoP9k|nu_L(R9jm*/:i"
}
