sudo ip route add 94.237.31.77 via 192.168.0.1 metric 1000
sudo ip route add default via 10.0.0.2
