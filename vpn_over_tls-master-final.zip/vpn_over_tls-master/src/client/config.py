config = {
	"SERVER_IP": "192.168.233.2",
	"SERVER_PORT": 443,
	"USERNAME": "dmitriy",
	"PASSWORD": "test",
	"TUN_NAME": "tun1",
	"SERVER_HOSTNAME": "strangebit.com",
	"CA_CERTIFICATE": "/home/mpaud002/5G_PQ/vpn_over_tls-master/src/newCerts/dilithium2/root/cacert.pem",
	"BUFFER_SIZE": 1500,
	"DEFAULT_GW": "192.168.233.2",
	"DNS_SERVER": "192.168.234.6"
}
