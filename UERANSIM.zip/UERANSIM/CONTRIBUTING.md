# Contributor Agreement

## 1. Agreement

Under this Contributor Agreement (“Agreement”), the party contributing to UERANSIM (“the Contributor”), hereby grants Ali GÜNGÖR (“the Project Owner”) the contributions made to the project.

## 2. License to Contributions

The Contributor hereby grants to the Project Owner, a perpetual, worldwide, non-exclusive, no-charge, royalty-free, irrevocable license to use the contributions in any manner the Project Owner deems fit.

## 3. Copyright

The Contributor represents that the contributions are original, and that the Contributor has the right to make the contributions without violating any copyrights, trademarks, or other intellectual property rights. By making contributions, the Contributor is allowing the Project Owner to use the contributions for the Project as deemed appropriate by the Project Owner.

## 4. Implicit Acceptance of Terms

By contributing to UERANSIM, the Contributor implicitly acknowledges and accepts the terms of this Agreement. It is the responsibility of the Contributor to read and understand the terms of this Agreement before making any contributions to UERANSIM.

---
