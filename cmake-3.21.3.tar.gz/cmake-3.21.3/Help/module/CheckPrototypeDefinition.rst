.. cmake-module:: ../../Modules/CheckPrototypeDefinition.cmake
