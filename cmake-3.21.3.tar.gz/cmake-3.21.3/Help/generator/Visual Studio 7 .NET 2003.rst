Visual Studio 7 .NET 2003
-------------------------

Removed.  This once generated Visual Studio .NET 2003 project files, but
the generator has been removed since CMake 3.9.  It is still possible to
build with VS 7.1 tools using the :generator:`NMake Makefiles` generator.
