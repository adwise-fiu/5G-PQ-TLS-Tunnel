// Generated automatically. Don't edit manually!

#define ASN_DISABLE_BER_SUPPORT 1
#define ASN_DISABLE_XER_SUPPORT 1
#define ASN_DISABLE_OER_SUPPORT 1
#define ASN_DISABLE_UPER_SUPPORT 1
